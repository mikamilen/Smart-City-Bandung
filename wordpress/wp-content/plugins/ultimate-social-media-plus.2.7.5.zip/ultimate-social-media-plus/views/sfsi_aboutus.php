<h1 class="abt_titl">
	<?php _e( 'Please visit us at', SFSI_PLUS_DOMAIN); ?> 
	<a href="http://ultimatelysocial.com"> Ultimatelysocial.com </a> 
	<?php _e( 'or write to us at', SFSI_PLUS_DOMAIN); ?> support@ultimatelysocial.com
</h1>

